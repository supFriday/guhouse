package cn.tedu.ttms.common.service;

public interface SysShiroService {
	void login(String username,String password);
}
